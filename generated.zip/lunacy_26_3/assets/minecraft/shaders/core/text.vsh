#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>






#define hue(v) ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.))

#define finalize() { texCoord0=UV0; }

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

vec4 lightmapped_color(vec4 color) {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    return color*sample_lightmap(Sampler2, UV2);
#else
    return color;
#endif
}

void f_4ae67fb9(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_fe569d43() {
    vertexColor=lightmapped_color(Color);
}


void f_e94ff8af(inout vec4 vertex) {
    f_4ae67fb9(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_fe569d43();
    }
    finalize();
}



void f_029d6381() {
    vertexColor=lightmapped_color(hue(gl_Position.x+safeGameTime()*1000.));
}

void f_fc9a51fa() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6.)) / 150.;
}

void f_c63db3b6(inout vec4 vertex) {
    f_4ae67fb9(vertex);
    f_029d6381();
    finalize();
}

void f_9dd7c372(inout vec4 vertex) {
    f_4ae67fb9(vertex);
    f_fe569d43();
    f_fc9a51fa();
    finalize();
}

void f_34bc54fe(inout vec4 vertex) {
    f_4ae67fb9(vertex);
    f_fc9a51fa();
    f_029d6381();
    finalize();
}

void f_36ad1d50(inout vec4 vertex) {
    f_fe569d43();
    float vertexId=mod(float(gl_VertexIndex), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_4ae67fb9(vertex);
    finalize();
}

void f_4677fa71(inout vec4 vertex) {
    float vertexId=mod(float(gl_VertexIndex), 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4.)*.1;
            vertex.y+=max(cos(scaledTime() / 4.)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4.)*3.;
            vertex.y-=max(cos(scaledTime() / 4.)*4., 0.);
        }
    }
    f_4ae67fb9(vertex);
    f_029d6381();
    finalize();
}

void f_905678ec(inout vec4 vertex, float speed) {
    f_4ae67fb9(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=lightmapped_color(Color*blink);
    finalize();
}



void f_5a50a35d(inout vec4 vertex) {
    f_4ae67fb9(vertex);
    f_fe569d43();
    vertexColor=vec4(1., 1., 1., vertexColor.a);
    finalize();
}


void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=fog_spherical_distance(Position);
    cylindricalVertexDistance=fog_cylindrical_distance(Position);
#endif
    f_fe569d43();

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255.+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85)) {
        f_e94ff8af(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9)) {
            gl_Position=vec4(2., 2., 2., 1.);
            f_fe569d43();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            f_4ae67fb9(vertex);
            f_fe569d43();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_9dd7c372(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            f_9dd7c372(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_36ad1d50(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_36ad1d50(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_905678ec(vertex, .5);
            return;
        }

        
        
    }

    
    
    if(iColor==ivec3(78, 92, 36)) {
        f_5a50a35d(vertex);
        return;
    }
    

    
    
    if(iColor==ivec3(230, 255, 254)) {
        f_c63db3b6(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250)) {
        f_9dd7c372(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254)) {
        f_34bc54fe(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250)) {
        f_36ad1d50(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254)) {
        f_4677fa71(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250)) {
        f_905678ec(vertex, .5);
        return;
    }

    
    

    
    
    if(iColor==ivec3(255, 255, 254)) {
        f_c63db3b6(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253)) {
        f_9dd7c372(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 252)) {
        f_34bc54fe(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251)) {
        f_36ad1d50(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254)) {
        f_4677fa71(vertex);
        return;
    }
    

    f_4ae67fb9(vertex);
    f_fe569d43();
    finalize();
}