#version 150

precision highp float;






#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { vertexDistance=length((ModelViewMat*vertex).xyz); texCoord0=UV0; }

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;


uniform sampler2D Sampler0;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

float safeGameTime() {
    float gameTime=GameTime;
    
    if(gameTime <= 0) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_9bd6c7c3(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_1c98d242() {
    vertexColor=Color*texelFetch(Sampler2, UV2 / 16, 0);
}


void f_87933916(inout vec4 vertex) {
    f_9bd6c7c3(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_1c98d242();
    }
    finalize();
}



void f_e0a891cd() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*texelFetch(Sampler2, UV2 / 16, 0);
}

void f_50a4b21e() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_d348d2ee(inout vec4 vertex) {
    f_9bd6c7c3(vertex);
    f_e0a891cd();
    finalize();
}

void f_77880a98(inout vec4 vertex) {
    f_9bd6c7c3(vertex);
    f_1c98d242();
    f_50a4b21e();
    finalize();
}

void f_b83297fd(inout vec4 vertex) {
    f_9bd6c7c3(vertex);
    f_50a4b21e();
    f_e0a891cd();
    finalize();
}

void f_e9f2c95a(inout vec4 vertex) {
    f_1c98d242();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_9bd6c7c3(vertex);
    finalize();
}

void f_f94c09f1(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e0a891cd();
    f_9bd6c7c3(vertex);
    finalize();
}

void f_66d162f6(inout vec4 vertex, float speed) {
    f_9bd6c7c3(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*texelFetch(Sampler2, UV2 / 16, 0);
    finalize();
}



void f_867febe9(inout vec4 vertex) {
    f_9bd6c7c3(vertex);
    f_1c98d242();
    vertexColor=vec4(1, 1, 1, vertexColor.a); 
    finalize();
}


void main() {
    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    
    
    if(iColor==ivec3(255, 85, 85))
    {
        f_87933916(vertex);
        return;
    }
    

    
    if(fract(Position.z) < .1) {
        
        
        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_1c98d242();
            finalize();
            return;
        }
        

        
        
        if(iColor==ivec3(57, 63, 63)) {
            
            
            f_9bd6c7c3(vertex);
            f_1c98d242();
            finalize();
            return;
        }

        
        if(iColor==ivec3(57, 63, 62)) {
            f_77880a98(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 63)) {
            
            f_77880a98(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 62, 62)) {
            f_e9f2c95a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 63)) {
            f_e9f2c95a(vertex);
            return;
        }

        
        if(iColor==ivec3(57, 61, 62)) {
            f_66d162f6(vertex, .5);
            return;
        }

        

        
    }

    
    
    if(iColor==ivec3(78, 92, 36))
    {
        f_867febe9(vertex);
        return;
    }
    

    
    
    
    if(iColor==ivec3(230, 255, 254))
    {
        f_d348d2ee(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 255, 250))
    {
        f_77880a98(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 254))
    {
        f_b83297fd(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 251, 250))
    {
        f_e9f2c95a(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 254))
    {
        f_f94c09f1(vertex);
        return;
    }

    
    if(iColor==ivec3(230, 247, 250))
    {
        f_66d162f6(vertex, .5);
        return;
    }

    
    

    
    
    
    if(iColor==ivec3(255, 255, 254))
    {
        f_d348d2ee(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 253))
    {
        f_77880a98(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 25))
    {
        f_b83297fd(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 255, 251))
    {
        f_e9f2c95a(vertex);
        return;
    }

    
    if(iColor==ivec3(255, 254, 254))
    {
        f_f94c09f1(vertex);
        return;
    }
    

    
    f_9bd6c7c3(vertex);
    f_1c98d242();
    finalize();
}